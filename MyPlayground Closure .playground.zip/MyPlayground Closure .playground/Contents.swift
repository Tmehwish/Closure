import UIKit

// Labeling Values
var val1 = 35
var val2 = 10
let answer = 35 * 10

// Closure Expression
let multi = {
    (val1: Int, val2: Int) -> Int in
    return val1 * val2
}
print (answer)
